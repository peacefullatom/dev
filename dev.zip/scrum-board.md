# scrum board

## sprint 2019.08 / 2

| plan                   | in work          | done                                                                                              |
| ---------------------- | ---------------- | ------------------------------------------------------------------------------------------------- |
| button group component | button component | make git cli section                                                                              |
| input component        |                  | note component                                                                                    |
| tabs component         |                  | refactor src\app\core\const\icon.ts, e.g. add prefix 'fa' to all constants, rename the file, etc. |
| spinner component      |                  | script to copy index.html to 404.html for github pages                                            |
| modal component        |                  | add meta information for search engines                                                           |

## sprint 2019.08 / 1

| plan           | in work              | done                           |
| -------------- | -------------------- | ------------------------------ |
| note component | make git cli section | code component                 |
|                |                      | make prerequisites             |
|                |                      | fix layout                     |
|                |                      | blockquote component           |
|                |                      | make vscode extensions section |

## sprint 2019.07

| plan | in work            | done                    |
| ---- | ------------------ | ----------------------- |
|      | make prerequisites | fix the footer          |
|      |                    | add margins to the body |
