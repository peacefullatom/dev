export const buttonPositiveId = 'buttonPositive';
