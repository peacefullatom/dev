export interface IStepperComponentSettings {
  max:number;
  min: number;
  step:number;
}