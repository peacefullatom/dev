export const stepperMax = 100;
export const stepperMin = 0;
export const stepperStep = 10;
