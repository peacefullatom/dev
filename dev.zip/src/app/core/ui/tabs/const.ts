export const tabsTypeAnchor = 'anchor';
export const tabsTypeButton = 'button';
