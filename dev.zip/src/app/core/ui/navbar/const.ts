export const navbarShowClass = 'show';
