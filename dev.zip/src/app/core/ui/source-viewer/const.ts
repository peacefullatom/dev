export const sourceViewerPath = 'assets/sources';
