export const bsNotePrimary = 'border border-primary';
export const bsNoteSecondary = 'border border-secondary';
export const bsNoteSuccess = 'border border-success';
export const bsNoteDanger = 'border border-danger';
export const bsNoteWarning = 'border border-warning';
export const bsNoteInfo = 'border border-info';
export const bsNoteLight = 'border border-light';
export const bsDarkDark = 'border border-dark';
