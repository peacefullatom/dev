import { indexPlacementLeft, indexPlacementRight } from './const';

export type IndexPlacement =
  | typeof indexPlacementLeft
  | typeof indexPlacementRight;
