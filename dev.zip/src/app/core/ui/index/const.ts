export const indexPlacementLeft = 'left';
export const indexPlacementRight = 'right';
