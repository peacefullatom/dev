export const idServiceSource = 'abcdefghijklmnopqrstuvwxyz0123456789';
export const idServiceLength = 6;
