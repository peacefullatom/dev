import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-utilities-intro',
  templateUrl: './utilities-intro.component.html',
  styleUrls: ['./utilities-intro.component.scss']
})
export class UtilitiesIntroComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
