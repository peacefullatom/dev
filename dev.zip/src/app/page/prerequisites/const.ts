/** an anchor for the git section in a prerequisites section */
export const gitAnchor = 'git';
