export const css3dFaceFront = 0;
export const css3dFaceBack = 1;
export const css3dFaceRight = 2;
export const css3dFaceLeft = 3;
export const css3dFaceTop = 4;
export const css3dFaceBottom = 5;

export const css3dFacesCount = 6;
