import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-misc-intro',
  templateUrl: './misc-intro.component.html',
  styleUrls: ['./misc-intro.component.scss']
})
export class MiscIntroComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
