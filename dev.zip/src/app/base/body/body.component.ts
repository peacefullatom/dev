import { Component, OnInit } from '@angular/core';

/** body component provides a top level router outlet */
@Component({
  selector: 'app-body',
  templateUrl: './body.component.html',
  styleUrls: ['./body.component.scss']
})
export class BodyComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
