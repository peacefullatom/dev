# backlog

- implement the automatic table of contents
- add section about vs code hot keys
- pull requests via cli
- refactor navbar to be usable in different places
- move the show css class to the bootstrap constants definition.

# old

- add meta information for search engines
- script to copy index.html to 404.html for github pages
- refactor src\app\core\const\icon.ts, e.g. add prefix 'fa' to all constants, rename the file, etc.
